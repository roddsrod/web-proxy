<!DOCTYPE html>
<html>
<head>

<title>Use but DON'T abuse ;) - Linux Proxy Strikes Back!</title>

<meta name="generator" content="php-proxy.com">
<meta name="version" content="<?=$version;?>">

<style type="text/css">
html body {
	font-family: Arial,Helvetica,sans-serif;
	font-size: 14px;
        background-color: #000219;
}

#container {
width:500px;
margin:0 auto;
margin-top:-325px;
}

#YT {
margin-top:50px;
text-align: center;
text-decoration: none;
}

#backup {
margin-top:105px;
text-align: center;
}

#error {
	color:red;
	font-weight:bold;
}

</style>

</head>

<body>

<center><img src="../logo.jpg"></center>
<div id="container">
	
	<?php if(isset($error_msg)){ ?>
	
	<div id="error">
		<p><?php echo $error_msg; ?></p>
	</div>
	
	<?php } ?>
	
	<div id="frm">
	
	<!-- I wouldn't touch this part -->
	
		<form action="index.php" method="post" style="margin-bottom:0;">
			<input name="url" type="text" style="width:450px;" autocomplete="on" />
			<input type="submit" value="Go" />
		</form>
		
		<script type="text/javascript">
			document.getElementsByName("url")[0].focus();
		</script>
		
	<!-- [END] -->
	
	</div>

	<div id="YT">
		<a href="../index.php?q=ytmpqdlxaGHb2qhnsKCmrK3GmGOc1aSU"><img src="../YTlogo.png"></a>
	</div>

	<div id="backup">
		<a href="../pr">Backup</a>
	</div>
</div>

</body>
</html>
